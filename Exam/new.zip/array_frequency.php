<?php
    $letter = "bangladesh";
	$length = strlen($letter);
	echo $length;
	$frequency = "";
	for($i=0;$i<$length;$i++){
		if($letter[$i]>="a" && $letter[$i]<="z"){
			$frequency = 
		}
		}
?>